const sonido = new Sonido();
let globalsSonido = { sonido, music: null };

const personaje = new Personaje();
let globalsPersonaje = { personaje };

const mapa = new Mapa();
let globalsMapa = { mapa };

const transicion = new Transicion();
let globalsTransicion = { transicion };

const tiempo = new Tiempo();
let globalsTiempo = { tiempo };

const puntos = new Puntos();
let globalsPuntos = { puntos };