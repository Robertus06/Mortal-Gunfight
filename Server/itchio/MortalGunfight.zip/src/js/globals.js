let mensaje = null;

let connection = new WebSocket('wss://mortal-gunfight.herokuapp.com/servidor');

const sonido = new Sonido();
let globalsSonido = { sonido, music: null };

const personaje = new Personaje();
let globalsPersonaje = { personaje };

const jugadores = new JugadoresOnline();
let globalsJugadores = { jugadores };

const mapa = new Mapa();
let globalsMapa = { mapa };

const transicion = new Transicion();
let globalsTransicion = { transicion };

const tiempo = new Tiempo();
let globalsTiempo = { tiempo };

const puntos = new Puntos();
let globalsPuntos = { puntos };

const consulta = new Consulta();
let globalsConsulta = { consulta };

const abandonado = new Abandonado();
let globalsAbandonado = { abandonado };